#ifndef EPUCK_LUA_DEBUG_QTUSERFUNCTIONS_H
#define EPUCK_LUA_DEBUG_QTUSERFUNCTIONS_H

#include <argos3/plugins/simulator/visualizations/qt-opengl/qtopengl_user_functions.h>

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

using namespace argos;

class CEPuckLuaDebugQTUserFunctions : public CQTOpenGLUserFunctions {
public:
   CEPuckLuaDebugQTUserFunctions();
   virtual ~CEPuckLuaDebugQTUserFunctions() {}

   virtual void DrawInWorld() override;

private:
   UInt8 GetLuaWord(lua_State* pt_lua_state);
   bool GetLuaVector(lua_State* pt_lua_state,
                     const std::string& str_name,
                     Real& f_x,
                     Real& f_y);
   CColor WordToColor(UInt8 un_word);
};

#endif
