

-- Global (parameters, variables, functions)
my_id = 999

-- Debug Variable
word = 0
targetRed   = { x = 0.00, y = 0.00 }
targetGreen = { x = 0.00, y = 0.00 }
-- 


-- Base Function INIT - once, at the beginning
function init()
  my_id = tonumber(robot.id:sub(3))
  log("hello world, I am " .. my_id)
end


-- Base Function STEP - at every tick
function step()
    word = (word + 1) % 256

    targetRed = { x = 2, y = 1 }
    targetGreen.x = targetGreen.x + 0.001 
    targetGreen.y = targetGreen.y - 0.0015 
end


-- Base Function RESET - once, when pressing the reset button
function reset()
	word = 0

	targetRed   = { x = 0.00, y = 0.00 }
	targetGreen = { x = 0.00, y = 0.00 }
end


-- Base Function DESTROY - once, when deleting a robot
function destroy()
    
end


