#include "epuck_lua_debug_qtuserfunctions.h"

#include <argos3/core/simulator/simulator.h>
#include <argos3/core/simulator/space/space.h>
#include <argos3/core/simulator/entity/controllable_entity.h>
#include <argos3/core/simulator/entity/embodied_entity.h>
#include <argos3/core/wrappers/lua/lua_controller.h>
#include <argos3/core/utility/math/vector3.h>
#include <argos3/core/utility/math/quaternion.h>
#include <argos3/core/utility/math/ray3.h>
#include <argos3/plugins/robots/e-puck/simulator/epuck_entity.h>

using namespace argos;

CEPuckLuaDebugQTUserFunctions::CEPuckLuaDebugQTUserFunctions() {}

UInt8 CEPuckLuaDebugQTUserFunctions::GetLuaWord(lua_State* pt_lua_state) {
   lua_getglobal(pt_lua_state, "word");

   UInt8 un_word = 0;
   if(lua_isnumber(pt_lua_state, -1)) {
      int n = static_cast<int>(lua_tointeger(pt_lua_state, -1));
      if(n < 0) n = 0;
      if(n > 255) n = 255;
      un_word = static_cast<UInt8>(n);
   }

   lua_pop(pt_lua_state, 1);
   return un_word;
}

bool CEPuckLuaDebugQTUserFunctions::GetLuaVector(lua_State* pt_lua_state,
                                                 const std::string& str_name,
                                                 Real& f_x,
                                                 Real& f_y) {
   lua_getglobal(pt_lua_state, str_name.c_str());

   if(!lua_istable(pt_lua_state, -1)) {
      lua_pop(pt_lua_state, 1);
      return false;
   }

   lua_getfield(pt_lua_state, -1, "x");
   lua_getfield(pt_lua_state, -2, "y");

   bool b_ok = lua_isnumber(pt_lua_state, -2) && lua_isnumber(pt_lua_state, -1);

   if(b_ok) {
      f_x = static_cast<Real>(lua_tonumber(pt_lua_state, -2));
      f_y = static_cast<Real>(lua_tonumber(pt_lua_state, -1));
   }

   lua_pop(pt_lua_state, 3);
   return b_ok;
}

CColor CEPuckLuaDebugQTUserFunctions::WordToColor(UInt8 un_word) {
   if(un_word < 85) {
      return CColor(255 - 3 * un_word, 3 * un_word, 0);
   }
   else if(un_word < 170) {
      UInt8 t = un_word - 85;
      return CColor(0, 255 - 3 * t, 3 * t);
   }
   else {
      UInt8 t = un_word - 170;
      return CColor(3 * t, 0, 255 - 3 * t);
   }
}

void CEPuckLuaDebugQTUserFunctions::DrawInWorld() {
   CSpace::TMapPerType& tEPucks =
      CSimulator::GetInstance().GetSpace().GetEntitiesByType("epuck");

   for(auto it = tEPucks.begin(); it != tEPucks.end(); ++it) {
      CEPuckEntity* pcEPuck = any_cast<CEPuckEntity*>(it->second);

      CControllableEntity& cControllable = pcEPuck->GetControllableEntity();
      CCI_Controller& cController = cControllable.GetController();

      CLuaController* pcLuaController =
         dynamic_cast<CLuaController*>(&cController);
      if(pcLuaController == nullptr) {
         continue;
      }

      lua_State* ptLuaState = pcLuaController->GetLuaState();
      if(ptLuaState == nullptr) {
         continue;
      }

      UInt8 unWord = GetLuaWord(ptLuaState);

      Real fRedX = 0.0f, fRedY = 0.0f;
      Real fGreenX = 0.0f, fGreenY = 0.0f;

      bool bHasRed = GetLuaVector(ptLuaState, "targetRed", fRedX, fRedY);
      bool bHasGreen = GetLuaVector(ptLuaState, "targetGreen", fGreenX, fGreenY);

      const CVector3& cPos =
         pcEPuck->GetEmbodiedEntity().GetOriginAnchor().Position;
      const CQuaternion& cOrient =
         pcEPuck->GetEmbodiedEntity().GetOriginAnchor().Orientation;

      CVector3 cDiskPos(cPos.GetX(), cPos.GetY(), 0.001f);

      if( unWord != 0) {
          DrawCircle(
             cDiskPos,
             CQuaternion(),
             0.05f,
             WordToColor(unWord),
             true,
             24);
      }

      if(bHasRed) {
         CVector3 cLocalRed(fRedX, fRedY, 0.0f);
         cLocalRed.Rotate(cOrient);
         CVector3 cWorldRed = cDiskPos + cLocalRed;
         DrawRay(CRay3(cDiskPos, cWorldRed), CColor::RED, 2.0f);
      }

      if(bHasGreen) {
         CVector3 cLocalGreen(fGreenX, fGreenY, 0.0f);
         cLocalGreen.Rotate(cOrient);
         CVector3 cWorldGreen = cDiskPos + cLocalGreen;
         DrawRay(CRay3(cDiskPos, cWorldGreen), CColor::GREEN, 2.0f);
      }
   }
}

REGISTER_QTOPENGL_USER_FUNCTIONS(
   CEPuckLuaDebugQTUserFunctions,
   "epuck_lua_debug_qtuserfunctions")
