

-- GLOBAL PARAMETERS

-- This parameter defines the upper bound of robot speed.
MAX_SPEED = 15

-- Special identifier indicating that no leader is assigned.
NO_LEADER = 999

-- Threshold distance below which two robots are considered to have "met".
MEET_DIST = 30

-- Finite State Machine (FSM) states
FREE     = 10     -- independent exploration
LEADER   = 80     -- group leader
FOLLOWER = 180     -- robot following a leader

-- Timeout thresholds for state recovery
LOST_TIMEOUT = 10

-- GLOBAL STATE VARIABLES

debug = true

my_id = 999

-- state
state = FREE

-- Identifier of the leader currently being followed
leader_id = NO_LEADER

-- Internal heading used for random walk
random_walk_angle = 0

-- Counter: consecutive timesteps without perceiving the leader
lost_tick = 0
 
-- Debug Variable!!!
word = 0

targetRed   = { x = 0.00, y = 0.00 }
targetGreen = { x = 0.00, y = 0.00 }
-- 

--------------------------------------------------
-- MAIN CONTROL LOOP
--------------------------------------------------

function init()
  my_id = tonumber( string.match(robot.id, "%d+") )
end


function reset()
   switch_to_free()
   random_walk_angle = 0
end


function destroy()

end


function step()

   -- state in FREE, LEADER, FOLLOWER
	if state == FREE then
		-- Behavior

        -- Visualisation
      robot.overo_leds.set_all_colors(0, 0, 255)

		-- Transition
      transition_from_free()


   elseif state == LEADER then
		-- Behavior

        -- Visualisation
      robot.overo_leds.set_all_colors(255, 0, 0)

		-- Transition
      transition_from_leader()


   elseif state == FOLLOWER then
		-- Behavior

        -- Visualisation
      robot.overo_leds.set_all_colors(255, 255, 0)

		-- Transition
      transition_from_follower()

   end


  -- These weights determine the relative influence of each behavior.
  wProx   = -8     -- obstacle avoidance (repulsive)
  wRand   = 5     -- random exploration
  wFollow = 10    -- attraction toward leader

   -- Apply force to robot
  local sumF = wProx   * proximity_to_force()
             + wRand   * random_walk_force()
             + wFollow * leader_to_force()

  sumF = safe_normalize(sumF)
  force_to_wheels(sumF)

  -- Communication
  if debug then
    log("SEND  id=", my_id, " leader_id=", leader_id, " state=", state, "\n")
  end

  -- Message structure: {my_id, leader_id, state, unused}
  robot.range_and_bearing.set_data( {my_id, leader_id, state, 0} )


  -- DEBUG
  word = state

   local f = vector2(0, 0)

   if leader_id == NO_LEADER then
      targetRed = {x=0, y=0}
   else

     for i = 1, #robot.range_and_bearing do
       local packet = robot.range_and_bearing[i]

        if packet.data[1] == leader_id then -- check if other id is my leader id
          local dir = vector2(packet.range, 0)
          dir:rotate(packet.bearing)
          targetRed = {x=dir.x/100, y=dir.y/100}
          break -- the robot is only attracted to one leader, first comes, first serves
       end
     end
   end

  --
 

end



--------------------------------------------------
-- FSM STATE CHANGE HELPERS
--------------------------------------------------

function switch_to_free()
   state = FREE
   leader_id = NO_LEADER
   lost_tick = 0
end

function switch_to_leader()
   state = LEADER
   leader_id = NO_LEADER
   lost_tick = 0
end

function switch_to_follower(new_leader_id)
   state = FOLLOWER
   leader_id = new_leader_id
   lost_tick = 0
end

 
--------------------------------------------------
-- TRANSITIONS
--------------------------------------------------

function transition_from_free()

   for i = 1, #robot.range_and_bearing do
      local packet = robot.range_and_bearing[i]
 
      local other_id     = packet.data[1]
      local other_leader = packet.data[2]
      local other_state   = packet.data[3]
      local dist         = packet.range

      if other_id ~= my_id and dist < MEET_DIST then

         -- Case 1: FREE meets FREE
         if other_state == FREE then 
            if my_id < other_id then
               switch_to_leader()
            else
               switch_to_follower(other_id)
            end

            break
         end

         -- Case 2: FREE meets FOLLOWER
         if other_state == FOLLOWER then
            switch_to_follower(other_leader)
            break
         end

         -- Case 3: FREE meets LEADER
         if other_state == LEADER then
            switch_to_follower(other_id)
            break    
         end

      end
   end

end


function transition_from_leader()
   if is_follower_in_range() then
      lost_tick = 0
   else
      lost_tick = lost_tick + 1
      if lost_tick >= LOST_TIMEOUT then
         -- Leader returns to FREE if no followers are perceived after the thredshold
         switch_to_free()
      end
   end
end


function transition_from_follower()
   if is_leader_in_range() then
      lost_tick = 0
   else
      lost_tick = lost_tick + 1
      if lost_tick >= LOST_TIMEOUT then
         -- Follower returns to FREE if its leader is lost.
         switch_to_free()
      end
   end
end


--------------------------------------------------
-- FORCE COMPUTATIONS
--------------------------------------------------

 
-- Attraction force to the leader with range and bearing
function leader_to_force()

   local f = vector2(0, 0)

   if leader_id == NO_LEADER then
      return f
   end

   for i = 1, #robot.range_and_bearing do
      local packet = robot.range_and_bearing[i]

      if packet.data[1] == leader_id then -- check if other id is my leader id
         local dir = vector2(1, 0)
         dir:rotate(packet.bearing)
         f = dir
         break -- the robot is only attracted to one leader, first comes, first serves
      end

   end

   return f

end


--------------------------------------------------
-- UTILITY FUNCTIONS
--------------------------------------------------

-- check if leader or follower is in range 

function is_leader_in_range()
-- Return true if on of my neighbor´s ID is my leader´s ID
   for i = 1, #robot.range_and_bearing do
      if robot.range_and_bearing[i].data[1] == leader_id then
         return true
      end
   end

   return false
end

function is_follower_in_range()
-- Return true if on of my neighbor´s ID is my follower´s ID
   for i = 1, #robot.range_and_bearing do
      if robot.range_and_bearing[i].data[2] == my_id then
         return true
      end
    end

   return false
end


function safe_normalize(v)

   if v == nil then
      return vector2(0, 0)
   end

   local len = v:length()

   -- Avoid crashes when the resulting force is zero.
   if len == nil or len <= 0 or len ~= len then -- TODO check which are necessary
      return vector2(0, 0)
   end

   return vector2(v.x / len, v.y / len)

end

-- ======================= =======================
-- =======================
-- SUB FUNCTIONS =========
-- =======================
-- ======================= =======================

-- ===============================
-- FORCE - RANDOM WALK ===========
-- ===============================

RW_TURN_DURATION = 6
RW_FORWARD_DURATION = 20

rw_counter = math.floor( math.random() * (RW_FORWARD_DURATION + RW_TURN_DURATION) )
rw_turn_angle = 0

function random_walk_force()
  local cycle = RW_TURN_DURATION + RW_FORWARD_DURATION
  rw_counter = (rw_counter % cycle) + 1

  -- choose a new random turning direction at the beginning of each cycle
  if rw_counter == 1 then
    rw_turn_angle = (math.random() - 0.5) * math.pi
  end

  if rw_counter <= RW_TURN_DURATION then
    local f = vector2(1, 0)
    f:rotate(rw_turn_angle)
    return f
  else
    return vector2(1, 0)
  end
end

-- ===============================
-- FORCE - RANGE_BEARING =========
-- ===============================

function rab_to_force()
  local f = vector2(0, 0)

  for _, p in ipairs(robot.range_and_bearing) do 

    local dir = vector2(1, 0)
    dir:rotate(p.bearing) -- direction of the vector based on the bearing

    local w = 1 / p.range -- strength of the force invertly related to the range

    f = f + dir * w
  end

  return f
end

-- ===============================
-- FORCE - PROXIMITY =============
-- ===============================

function proximity_to_force()

  local f = vector2(0, 0)

  -- IMPORTANT >> the # bellow is a shortcut to access the length of a table
  for i = 1, #robot.proximity do
    -- value/angle from the proximity sensor
    local value = robot.proximity[i].value
    local angle = robot.proximity[i].angle

    -- we compute the direction vector of the sensor
    local dir = vector2(1, 0)
    dir:rotate(angle)

    -- and we add it as an atttractive force
    f = f + dir * value
  end


  return f
end

-- ===============================
-- FORCE - LIGHT =================
-- ===============================

function light_to_force()

  local f = vector2(0, 0)

  for i = 1, #robot.light do
    local value = robot.light[i].value
    local angle = robot.light[i].angle

    local dir = vector2(1, 0)
    dir:rotate(angle)

    -- attraction: pull toward the light direction
    f = f + dir * value
  end

  return f
end

-- ===============================
-- FORCE - KEEP DISTANCE =========
-- ===============================

function rab_keep_distance(target_dist)
  local f = vector2(0, 0)

  -- desired inter-robot distance
--  local target_dist = 35
  local EPSILON = 50
  local MIN_RANGE = 0.01  -- safety to avoid division by zero

  for _, p in ipairs(robot.range_and_bearing) do
    local d = math.max(p.range, MIN_RANGE)

    -- Lennard-Jones style interaction
    -- positive = attraction, negative = repulsion
    local lj = -(4 * EPSILON / d) *
               ((target_dist / d)^4 - (target_dist / d)^2)

    local dir = vector2(1, 0)
    dir:rotate(p.bearing)

    f = f + dir * lj
  end

  return f
end

-- =======================
-- FORCE TO WHEEL ========
-- =======================

function force_to_wheels(f)
  local a = math.atan(f.y, f.x)

  -- forward intensity:
  -- math.cos(a) when ahead, 0 when at 90° or more
  local forward = math.cos(a)
  if forward < 0 then
    forward = 0
  end

  -- turning intensity
  local K_TURN = 5
  local turn = K_TURN * a

  local left  = MAX_SPEED * forward - turn
  local right = MAX_SPEED * forward + turn

  -- optional clamp to avoid excessive wheel speeds
  if left > MAX_SPEED then left = MAX_SPEED end
  if left < -MAX_SPEED then left = -MAX_SPEED end
  if right > MAX_SPEED then right = MAX_SPEED end
  if right < -MAX_SPEED then right = -MAX_SPEED end

  robot.wheels.set_velocity(left, right)
end

-- =======================
-- ODOMETRY ==============
-- =======================

function update_vector_with_odometry(v)
  local dl = robot.wheels.distance_left
  local dr = robot.wheels.distance_right
  local L  = robot.wheels.axis_length

  local dtheta = (dr - dl) / L
  local d = (dr + dl) / 2

  v = v - vector2(d, 0)
  v:rotate(-dtheta)

  return v
end
