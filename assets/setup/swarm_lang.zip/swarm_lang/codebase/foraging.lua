
MAX_SPEED = 10
angle = 0

BLACK_THRESHOLD = 0.3
GREY_THRESHOLD = 0.3
REACHING_RANGE = 5

-- put an _ in front of the name of the variable you want to appear on top of the inspector, so you can see them live !
_state = "EXPLORE"

resource = nil
nest = nil
target = nil

-- Debug Variable!!!
word = 0

targetRed   = { x = 0.00, y = 0.00 }
targetGreen = { x = 0.00, y = 0.00 }
-- 


function init()

end


function step()

-- update all stored vectors with odometry
  if resource then resource = update_vector_with_odometry(resource) end
  if nest then nest = update_vector_with_odometry(nest) end
  if target then target = update_vector_with_odometry(target) end

  -- Debug
  if     _state == "EXPLORE" then word = 10
  elseif _state == "TO_NEST" then word = 100
  elseif _state == "TO_RESOURCE" then word = 180
  end

  if resource then
    targetRed   = {x= resource.x/100, y= resource.y/100}
  else
    targetRed   = {x= 0, y= 0}
  end

  if nest then
    targetGreen = {x= nest.x/100, y= nest.y/100}
  else
    targetGreen = {x= 0, y= 0}
  end


  -- detect zones
  local on_resource = robot.ground.center > GREY_THRESHOLD and robot.ground.center < 0.7
  local on_nest     = robot.ground.center < BLACK_THRESHOLD

  if on_resource then
    resource = vector2(0,0)
  end

  if on_nest then
    nest = vector2(0,0)
  end


  if _state == "EXPLORE" then
    robot.overo_leds.set_all_colors(0,0,0)
    if resource then robot.overo_leds.set_single_color(1, 1,0,0) end
    if nest     then robot.overo_leds.set_single_color(2, 0,0,1) end

    if resource and nest then
      _state = "TO_NEST"
      target = nest

    	if on_nest then
        _state = "TO_RESOURCE"
        target = resource
      end
    end

  elseif _state == "TO_RESOURCE" then
    robot.overo_leds.set_all_colors(1,0,0)
    target = resource
	 
    if on_resource then
      _state = "TO_NEST"
      target = nest
    end

    if resource:length() < REACHING_RANGE then
      resource = nil
      target = nil
      _state = "EXPLORE"
  	 end

  elseif _state == "TO_NEST" then
    robot.overo_leds.set_all_colors(0,0,1)
    target = nest

    if on_nest then
      _state = "TO_RESOURCE"
      target = resource
    end

    if nest:length() < REACHING_RANGE then
      nest = nil
      target = nil
      _state = "EXPLORE"
  	 end

  end

  wProx = -10
  wRand = 1
  wTarg = 1
  wRAB = -1

  f = vector2(0,0)

  if _state == "EXPLORE" then
  	 f = wProx * proximity_to_force() + wRAB * rab_to_force() + wRand * random_walk_force()
  else
    targ = vector2(target.x, target.y)
	 targ:normalize()
    f = wProx * proximity_to_force() + wRAB * rab_to_force() + wTarg * targ
  end


  force_to_wheels(f)

end



function reset()
  state = "EXPLORE"

  resource = nil
  nest = nil
  target = nil
end




function destroy()
end


-- ======================= =======================
-- =======================
-- SUB FUNCTIONS =========
-- =======================
-- ======================= =======================

-- ===============================
-- FORCE - RANDOM WALK ===========
-- ===============================

RW_TURN_DURATION = 6
RW_FORWARD_DURATION = 20

rw_counter = math.floor( math.random() * (RW_FORWARD_DURATION + RW_TURN_DURATION) )
rw_turn_angle = 0

function random_walk_force()
  local cycle = RW_TURN_DURATION + RW_FORWARD_DURATION
  rw_counter = (rw_counter % cycle) + 1

  -- choose a new random turning direction at the beginning of each cycle
  if rw_counter == 1 then
    rw_turn_angle = (math.random() - 0.5) * math.pi
  end

  if rw_counter <= RW_TURN_DURATION then
    local f = vector2(1, 0)
    f:rotate(rw_turn_angle)
    return f
  else
    return vector2(1, 0)
  end
end

-- ===============================
-- FORCE - RANGE_BEARING =========
-- ===============================

function rab_to_force()
  local f = vector2(0, 0)

  for _, p in ipairs(robot.range_and_bearing) do 

    local dir = vector2(1, 0)
    dir:rotate(p.bearing) -- direction of the vector based on the bearing

    local w = 1 / p.range -- strength of the force invertly related to the range

    f = f + dir * w
  end

  return f
end

-- ===============================
-- FORCE - PROXIMITY =============
-- ===============================

function proximity_to_force()

  local f = vector2(0, 0)

  -- IMPORTANT >> the # bellow is a shortcut to access the length of a table
  for i = 1, #robot.proximity do
    -- value/angle from the proximity sensor
    local value = robot.proximity[i].value
    local angle = robot.proximity[i].angle

    -- we compute the direction vector of the sensor
    local dir = vector2(1, 0)
    dir:rotate(angle)

    -- and we add it as an atttractive force
    f = f + dir * value
  end


  return f
end

-- ===============================
-- FORCE - LIGHT =================
-- ===============================

function light_to_force()

  local f = vector2(0, 0)

  for i = 1, #robot.light do
    local value = robot.light[i].value
    local angle = robot.light[i].angle

    local dir = vector2(1, 0)
    dir:rotate(angle)

    -- attraction: pull toward the light direction
    f = f + dir * value
  end

  return f
end

-- ===============================
-- FORCE - KEEP DISTANCE =========
-- ===============================

function rab_keep_distance(target_dist)
  local f = vector2(0, 0)

  -- desired inter-robot distance
--  local target_dist = 35
  local EPSILON = 50
  local MIN_RANGE = 0.01  -- safety to avoid division by zero

  for _, p in ipairs(robot.range_and_bearing) do
    local d = math.max(p.range, MIN_RANGE)

    -- Lennard-Jones style interaction
    -- positive = attraction, negative = repulsion
    local lj = -(4 * EPSILON / d) *
               ((target_dist / d)^4 - (target_dist / d)^2)

    local dir = vector2(1, 0)
    dir:rotate(p.bearing)

    f = f + dir * lj
  end

  return f
end

-- =======================
-- FORCE TO WHEEL ========
-- =======================

function force_to_wheels(f)
  local a = math.atan(f.y, f.x)

  -- forward intensity:
  -- math.cos(a) when ahead, 0 when at 90° or more
  local forward = math.cos(a)
  if forward < 0 then
    forward = 0
  end

  -- turning intensity
  local K_TURN = 5
  local turn = K_TURN * a

  local left  = MAX_SPEED * forward - turn
  local right = MAX_SPEED * forward + turn

  -- optional clamp to avoid excessive wheel speeds
  if left > MAX_SPEED then left = MAX_SPEED end
  if left < -MAX_SPEED then left = -MAX_SPEED end
  if right > MAX_SPEED then right = MAX_SPEED end
  if right < -MAX_SPEED then right = -MAX_SPEED end

  robot.wheels.set_velocity(left, right)
end

-- =======================
-- ODOMETRY ==============
-- =======================

function update_vector_with_odometry(v)
  local dl = robot.wheels.distance_left
  local dr = robot.wheels.distance_right
  local L  = robot.wheels.axis_length

  local dtheta = (dr - dl) / L
  local d = (dr + dl) / 2

  v = v - vector2(d, 0)
  v:rotate(-dtheta)

  return v
end
