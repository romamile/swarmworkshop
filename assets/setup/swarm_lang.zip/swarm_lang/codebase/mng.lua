
-- Debug Variable!!!
word = 0

targetRed   = { x = 0.00, y = 0.00 }
targetGreen = { x = 0.00, y = 0.00 }
-- 

voc = {}
my_id = 999

function init()

  my_id = tonumber(robot.id:sub(3))
  
end


function step()

  --log("---")
  for i = 1, #voc do
    word = voc[1]
    --log(voc[i] .. " ")
  end


  local busy = false

    -- First check if you need to act as a hearer
  busy = hearer_step()
  
    -- If not, maybe you might act as a speaker then
  -- MIGHT WANT TO ADD A PROBABILITY!
  if not busy then
    busy = speaker_step()
  end

    -- If not, then broadcast about yourself
  if not busy then
    send_beacon()
  end

end


function reset()
   -- put your code here
	voc = {}
end


function destroy()
end



-- ============ =================
-- LANGUAGE === =================
-- ============ =================

function speaker_step()
    
  local pSpeak = 1

    -- Should we speak?
  if (math.random() > pSpeak) then
    return false
  end

    -- Build list of neighboors and their ids
  local neighboors = {}
  for i = 1, #robot.range_and_bearing do
    neighboors[#neighboors + 1] = robot.range_and_bearing[i].data[1]
  end

    -- No neighboors :(
  if #neighboors == 0 then
    return false
  end

    -- pick a random neighboors
  local hearer_id = neighboors[math.random(#neighboors)]

    -- no known words, then invent one!
  if #voc == 0 then
    voc[1] = math.random(1,255)
  end

  local word = voc[1]

  start_game(hearer_id, word)
  return true
end


function hearer_step()

  for i = 1, #robot.range_and_bearing do
    local from    = robot.range_and_bearing[i].data[1]
    local target  = robot.range_and_bearing[i].data[2]
    local type    = robot.range_and_bearing[i].data[3]
    local payload = robot.range_and_bearing[i].data[4]

    -- If I receive a message from a speaker, addressed to me then I answer
    if type == 1 and target == tonumber(robot.id:sub(3)) then
      local word = payload
      -- check if word is in vocabulary
      local success = 0
      for j = 1, #voc do
        if voc[j] == word then
          success = 1
          break
        end
      end

      if success == 1 then -- simplify vocabulary to only that word
        voc = {word}
      else -- add word to vocabulary
        voc[#voc + 1] = word
      end

      -- == Send Answer ==
      send_answer(from, success)
      return true
    end
  end

  return false
end


function send_beacon()
    -- the 0 in third place means we are broadcasting our presence
  robot.range_and_bearing.set_data( {tonumber(robot.id:sub(3)), 0, 0, 0} )
end


function start_game(hearer_id, word)
    -- the 1 in third place means we want to start a game
  robot.range_and_bearing.set_data( {tonumber(robot.id:sub(3)), hearer_id, 1, word} )
end


function send_answer(speaker_id, success)
    -- the 2 in third place means we are answering in a game
  robot.range_and_bearing.set_data( {tonumber(robot.id:sub(3)), speaker_id, 2, success} )
end
