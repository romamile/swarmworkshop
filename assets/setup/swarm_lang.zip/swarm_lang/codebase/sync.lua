

-- Debug Variable!!!
word = 0

targetRed   = { x = 0.00, y = 0.00 }
targetGreen = { x = 0.00, y = 0.00 }
-- 

period = 50
alpha = 0.2

counter = 0

function init()
  counter = robot.random.uniform(period)
end



function step()
  robot.range_and_bearing.set_data({0,0,0,0})

  counter = counter + 1

  -- check reception
  local received = false
  for _, p in ipairs(robot.range_and_bearing) do
    if p.data[1] == 1 then
      received = true
      break
    end
  end

  -- coupling (only before firing)
  if counter < period and received then
    counter = counter + alpha * counter
    if counter >= period then
      counter = period
    end
  end

  -- reset immediately after firing
  if counter >= period then
    robot.range_and_bearing.set_data({1,0,0,0})
    counter = 0
  end


 -- Visualisation
 if counter < 3 then
    robot.overo_leds.set_all_colors(1,1,0)
  else
    robot.overo_leds.set_all_colors(0,0,0)
  end

end


function reset()
	counter = robot.random.uniform(TOP)
end

